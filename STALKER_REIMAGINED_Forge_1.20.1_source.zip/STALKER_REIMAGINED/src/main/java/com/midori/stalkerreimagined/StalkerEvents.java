package com.midori.stalkerreimagined;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Aparicion natural (a cualquier hora, UN stalker a la vez), jumpscare al morir y el Silent Distorsionado.
 */
@Mod.EventBusSubscriber(modid = StalkerReimagined.MODID)
public final class StalkerEvents {
    private StalkerEvents() {}

    private static final Random RNG = new Random();

    // ---- aparicion natural ----
    private static final int CHECK_TICKS = 200;     // cada 10 s
    private static final double CHANCE = 0.25;
    private static final int COOLDOWN = 600;        // 30 s por jugador
    private static final int NEAR = 128;            // si hay un stalker a esta distancia, no aparece otro
    private static final int MIN = 28, MAX = 60;

    private static final Object[][] POOL = {
            {StalkerType.STALKER, 6}, {StalkerType.HUNTER_STALKER, 4}, {StalkerType.EVENT_STALKER, 3}, {StalkerType.CAVE_STALKER, 3},
            {StalkerType.STALKER_BIPEDAL_DOOR, 3}, {StalkerType.TREE_STALKER, 3}, {StalkerType.YELLING_STALKER, 3},
            {StalkerType.BOILED_ONE, 2}, {StalkerType.DOOR_STALK, 2}, {StalkerType.ORIMMY_STALKER, 2}, {StalkerType.PEEKING_STALKER, 2},
            {StalkerType.SILENT_STALKER, 2}, {StalkerType.HAND, 3}, {StalkerType.HAND_2, 3}, {StalkerType.LUSTER_STALKER, 3}, {StalkerType.THE_LOCUST, 2},
            {StalkerType.TORMENTOR, 2}, {StalkerType.TORMENTOR_DOOR, 2}, {StalkerType.EVILSTALKER, 1},
    };
    private static final Map<UUID, Integer> nextSpawn = new HashMap<>();

    private static StalkerType pick() {
        int total = 0;
        for (Object[] e : POOL) total += (Integer) e[1];
        int r = RNG.nextInt(total);
        for (Object[] e : POOL) {
            r -= (Integer) e[1];
            if (r < 0) return (StalkerType) e[0];
        }
        return StalkerType.STALKER;
    }

    // ---- Silent Distorsionado ----
    private static final class Pending {
        final UUID player;
        int waited;
        Pending(UUID player) { this.player = player; }
    }
    private static final List<Pending> pending = new ArrayList<>();

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = e.getServer();
        int tick = server.getTickCount();
        if (tick % CHECK_TICKS == 0) naturalSpawn(server, tick);
        if (tick % 10 == 0) distortedTick(server);
    }

    private static void naturalSpawn(MinecraftServer server, int tick) {
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return;
        for (ServerPlayer p : level.players()) {
            try {
                if (p.isSpectator()) continue;
                if (tick < nextSpawn.getOrDefault(p.getUUID(), 0)) continue;
                if (RNG.nextDouble() > CHANCE) continue;
                // un solo stalker a la vez (el Follower y el Distorsionado no cuentan)
                List<StalkerEntity> existing = level.getEntitiesOfClass(StalkerEntity.class, p.getBoundingBox().inflate(NEAR),
                        s -> s.st != StalkerType.THE_FOLLOWER && s.st != StalkerType.SILENT_DISTORSIONADO);
                if (!existing.isEmpty()) continue;
                // bajo tierra solo aparece el Cave Stalker
                int topY = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(p.getX()), Mth.floor(p.getZ()));
                boolean underground = topY > p.getY() + 6;
                StalkerType type = underground ? StalkerType.CAVE_STALKER : pick();
                double lo = type == StalkerType.TORMENTOR ? 48 : MIN, hi = type == StalkerType.TORMENTOR ? 70 : MAX;
                for (int i = 0; i < 10; i++) {
                    double a = RNG.nextDouble() * Math.PI * 2, d = lo + RNG.nextDouble() * (hi - lo);
                    int x = Mth.floor(p.getX() + Math.cos(a) * d), z = Mth.floor(p.getZ() + Math.sin(a) * d);
                    BlockPos s = Util.surface(level, x, z);
                    if (s == null) continue;
                    StalkerEntity ent = StalkerReimagined.TYPES.get(type).get().create(level);
                    if (ent == null) break;
                    ent.moveTo(x + 0.5, s.getY(), z + 0.5, RNG.nextFloat() * 360F, 0);
                    level.addFreshEntity(ent);
                    nextSpawn.put(p.getUUID(), tick + COOLDOWN);
                    break;
                }
            } catch (Exception ex) {
                // chunk sin cargar
            }
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        try {
            if (!(e.getEntity() instanceof ServerPlayer victim)) return;
            if (!(e.getSource().getEntity() instanceof StalkerEntity killer)) return;
            Util.toPlayer(victim, ModSounds.JUMPSCARE.get(), 1.0F);
            if (killer.st == StalkerType.SILENT_STALKER || killer.st == StalkerType.SILENT_HABLANDO) pending.add(new Pending(victim.getUUID()));
            killer.discard(); // el stalker que te mato desaparece
        } catch (Exception ex) {
            // ya no existe
        }
    }

    private static void distortedTick(MinecraftServer server) {
        Iterator<Pending> it = pending.iterator();
        while (it.hasNext()) {
            Pending pd = it.next();
            pd.waited += 10;
            if (pd.waited < 200) continue;
            ServerPlayer p = server.getPlayerList().getPlayer(pd.player);
            if (p == null || pd.waited > 200 + 1200) { it.remove(); continue; } // nunca revivio
            if (!p.isAlive()) continue; // espera a que reaparezca
            ServerLevel level = p.serverLevel();
            for (int i = 0; i < 10; i++) {
                double a = RNG.nextDouble() * Math.PI * 2, d = 18 + RNG.nextDouble() * 8;
                int x = Mth.floor(p.getX() + Math.cos(a) * d), z = Mth.floor(p.getZ() + Math.sin(a) * d);
                BlockPos s = Util.surface(level, x, z);
                if (s == null) continue;
                StalkerEntity dd = StalkerReimagined.TYPES.get(StalkerType.SILENT_DISTORSIONADO).get().create(level);
                if (dd == null) break;
                dd.moveTo(x + 0.5, s.getY(), z + 0.5, 0, 0);
                level.addFreshEntity(dd);
                break;
            }
            it.remove();
        }
    }
}
