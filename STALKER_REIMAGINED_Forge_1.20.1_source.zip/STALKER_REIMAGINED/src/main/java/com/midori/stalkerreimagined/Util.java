package com.midori.stalkerreimagined;

import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Utilidades compartidas: mirar, puertas, ventanas, sonidos, terreno. */
public final class Util {
    private Util() {}

    // ---------- jugadores ----------
    public static ServerPlayer nearestPlayer(ServerLevel level, Vec3 pos, double range) {
        ServerPlayer best = null;
        double bd = range * range;
        for (ServerPlayer p : level.players()) {
            if (p.isSpectator() || !p.isAlive()) continue;
            double d = p.distanceToSqr(pos);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }

    public static List<ServerPlayer> playersNear(ServerLevel level, Vec3 pos, double range) {
        List<ServerPlayer> out = new ArrayList<>();
        for (ServerPlayer p : level.players()) {
            if (p.isSpectator() || !p.isAlive()) continue;
            if (p.distanceToSqr(pos) <= range * range) out.add(p);
        }
        return out;
    }

    // ---------- "lo estas mirando?" ----------
    /** true si el jugador apunta al punto (centro del cuerpo) y no hay un bloque en medio. */
    public static boolean isLookedAt(ServerPlayer p, Entity e, double centerY, double dot, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 target = e.position().add(0, centerY, 0);
        Vec3 d = target.subtract(eye);
        double dist = d.length();
        if (dist == 0 || dist > range) return false;
        Vec3 dir = d.scale(1.0 / dist);
        if (p.getViewVector(1.0F).dot(dir) <= dot) return false;
        if (dist > 3) {
            try {
                Vec3 to = eye.add(dir.scale(dist - 2));
                HitResult hit = p.level().clip(new ClipContext(eye, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                if (hit.getType() != HitResult.Type.MISS) return false;
            } catch (Exception ex) {
                // si falla la comprobacion se da por visto
            }
        }
        return true;
    }

    // ---------- sonidos ----------
    public static void toPlayer(ServerPlayer p, SoundEvent s, float volume) {
        p.playNotifySound(s, SoundSource.HOSTILE, volume, 1.0F);
    }

    public static void at(ServerLevel level, Vec3 pos, SoundEvent s, float volume, float pitch) {
        level.playSound(null, pos.x, pos.y, pos.z, s, SoundSource.HOSTILE, volume, pitch);
    }

    public static void stop(ServerPlayer p, SoundEvent s) {
        p.connection.send(new ClientboundStopSoundPacket(ForgeRegistries.SOUND_EVENTS.getKey(s), SoundSource.HOSTILE));
    }

    // ---------- terreno ----------
    /** posicion libre justo encima del terreno en (x, z), o null si el chunk no esta cargado. */
    public static BlockPos surface(ServerLevel level, int x, int z) {
        if (!level.hasChunk(x >> 4, z >> 4)) return null;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, y, z);
        if (!level.getFluidState(pos.below()).isEmpty()) return null;
        return pos;
    }

    public static boolean loaded(Level level, BlockPos pos) {
        return level.hasChunkAt(pos);
    }

    // ---------- bloques ----------
    public static String blockName(BlockState s) {
        var key = ForgeRegistries.BLOCKS.getKey(s.getBlock());
        return key == null ? "" : key.getPath();
    }

    public static boolean isGlass(BlockState s) {
        return blockName(s).contains("glass");
    }

    public static boolean isDoor(BlockState s) {
        Block b = s.getBlock();
        return b instanceof DoorBlock || b instanceof FenceGateBlock;
    }

    public static boolean isClosedDoorLower(BlockState s) {
        Block b = s.getBlock();
        if (b instanceof DoorBlock) {
            return !s.getValue(BlockStateProperties.OPEN) && s.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER;
        }
        if (b instanceof FenceGateBlock) return !s.getValue(BlockStateProperties.OPEN);
        return false;
    }

    public static boolean isLog(BlockState s) {
        String n = blockName(s);
        return n.contains("log") || n.endsWith("_wood") || n.contains("stem") || n.contains("hyphae") || n.contains("bamboo_block");
    }

    public static void openDoor(ServerLevel level, BlockPos pos) {
        BlockState s = level.getBlockState(pos);
        Block b = s.getBlock();
        if (b instanceof DoorBlock door) {
            if (s.getValue(BlockStateProperties.OPEN)) return;
            door.setOpen(null, level, s, pos, true);
            BlockPos other = s.getValue(BlockStateProperties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.LOWER ? pos.above() : pos.below();
            BlockState os = level.getBlockState(other);
            if (os.getBlock() instanceof DoorBlock && !os.getValue(BlockStateProperties.OPEN)) level.setBlock(other, os.setValue(BlockStateProperties.OPEN, true), 10);
        } else if (b instanceof FenceGateBlock) {
            if (!s.getValue(BlockStateProperties.OPEN)) level.setBlock(pos, s.setValue(BlockStateProperties.OPEN, true), 10);
        }
    }

    /** Puertas cerradas (mitad inferior) en un cubo alrededor de pos. */
    public static List<BlockPos> closedDoorsAround(ServerLevel level, BlockPos c, int radius) {
        List<BlockPos> out = new ArrayList<>();
        for (int dx = -radius; dx <= radius; dx++)
            for (int dy = -1; dy <= 2; dy++)
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos p = c.offset(dx, dy, dz);
                    if (!level.hasChunkAt(p)) continue;
                    if (isClosedDoorLower(level.getBlockState(p))) out.add(p);
                }
        return out;
    }

    public static void openDoorsAround(ServerLevel level, BlockPos c, int radius) {
        for (BlockPos p : closedDoorsAround(level, c, radius)) openDoor(level, p);
    }

    /** Puerta cerrada mas cercana a center. */
    public static BlockPos nearestClosedDoor(ServerLevel level, Vec3 center, int radius, int vert) {
        BlockPos c = BlockPos.containing(center);
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++)
                for (int dy = -vert; dy <= vert; dy++) {
                    double d = dx * dx + dy * dy + dz * dz;
                    if (d >= bd) continue;
                    BlockPos p = c.offset(dx, dy, dz);
                    if (!level.hasChunkAt(p)) continue;
                    if (isClosedDoorLower(level.getBlockState(p))) { best = p; bd = d; }
                }
        return best;
    }

    /** Puerta cerrada mas cercana que quede a la DERECHA del jugador (si ninguna, la mas cercana). */
    public static BlockPos rightDoor(ServerLevel level, ServerPlayer player, int radius, int vert) {
        BlockPos c = player.blockPosition();
        Vec3 view = player.getLookAngle();
        double vl = Math.hypot(view.x, view.z);
        if (vl == 0) vl = 1;
        double rx = -view.z / vl, rz = view.x / vl;
        BlockPos bestR = null, bestA = null;
        double dR = Double.MAX_VALUE, dA = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++)
                for (int dy = -vert; dy <= vert; dy++) {
                    double d = dx * dx + dy * dy + dz * dz;
                    if (d >= dA && d >= dR) continue;
                    BlockPos p = c.offset(dx, dy, dz);
                    if (!level.hasChunkAt(p)) continue;
                    if (!isClosedDoorLower(level.getBlockState(p))) continue;
                    if (d < dA) { bestA = p; dA = d; }
                    if (dx * rx + dz * rz > 0 && d < dR) { bestR = p; dR = d; }
                }
        return bestR != null ? bestR : bestA;
    }

    private static boolean solid(ServerLevel level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        return !s.isAir() && s.isSolidRender(level, p);
    }

    /** Bloque solido mas cercano a la DERECHA del jugador (desde sus pies hasta 'up' bloques arriba) con la cara hacia el jugador libre. */
    public static BlockPos rightSolid(ServerLevel level, ServerPlayer player, int radius, int up) {
        BlockPos c = player.blockPosition();
        Vec3 view = player.getLookAngle();
        double vl = Math.hypot(view.x, view.z);
        if (vl == 0) vl = 1;
        double rx = -view.z / vl, rz = view.x / vl;
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++) {
                double relx = c.getX() + dx + 0.5 - player.getX(), relz = c.getZ() + dz + 0.5 - player.getZ();
                if (relx * rx + relz * rz < 1.0) continue;
                for (int dy = 0; dy <= up; dy++) {
                    double d = relx * relx + relz * relz + dy * dy;
                    if (d >= bestD) continue;
                    BlockPos p = c.offset(dx, dy, dz);
                    if (!level.hasChunkAt(p) || !solid(level, p)) continue;
                    int sx = Math.abs(relx) >= Math.abs(relz) ? (relx > 0 ? -1 : 1) : 0;
                    int sz = sx == 0 ? (relz > 0 ? -1 : 1) : 0;
                    if (solid(level, p.offset(sx, 0, sz))) continue;
                    best = p; bestD = d;
                }
            }
        return best;
    }

    public static boolean isFree(ServerLevel level, BlockPos p) {
        return level.hasChunkAt(p) && level.getBlockState(p).isAir();
    }

    /** Ventana (vidrio) mas cercana a center y un hueco libre junto a ella (lado mas lejano al jugador si farFrom != null). */
    public static BlockPos[] windowSpot(ServerLevel level, Vec3 center, int radius, int up, int down, Vec3 farFrom, int maxCandidates) {
        BlockPos c = BlockPos.containing(center);
        List<BlockPos> cands = new ArrayList<>();
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++)
                for (int dy = -down; dy <= up; dy++) {
                    BlockPos p = c.offset(dx, dy, dz);
                    if (!level.hasChunkAt(p)) continue;
                    if (isGlass(level.getBlockState(p))) cands.add(p);
                }
        cands.sort(Comparator.comparingDouble(p -> p.distSqr(c)));
        int[][] sides = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        int n = 0;
        for (BlockPos g : cands) {
            if (n++ >= maxCandidates) break;
            List<BlockPos> free = new ArrayList<>();
            for (int[] s : sides) {
                BlockPos sp = g.offset(s[0], -1, s[1]);
                if (isFree(level, sp) && isFree(level, sp.above())) free.add(sp);
            }
            if (free.isEmpty()) continue;
            Vec3 ref = farFrom != null ? farFrom : center;
            if (farFrom != null) free.sort(Comparator.comparingDouble((BlockPos p) -> -Math.hypot(p.getX() + 0.5 - ref.x, p.getZ() + 0.5 - ref.z)));
            else free.sort(Comparator.comparingDouble((BlockPos p) -> Math.hypot(p.getX() + 0.5 - ref.x, p.getZ() + 0.5 - ref.z)));
            return new BlockPos[]{g, free.get(0)};
        }
        return null;
    }

    /** Rompe el vidrio y los vidrios pegados a el (la ventana completa), hasta max bloques. */
    public static void breakWindow(ServerLevel level, BlockPos start, int max) {
        java.util.Set<BlockPos> seen = new java.util.HashSet<>();
        java.util.ArrayDeque<BlockPos> queue = new java.util.ArrayDeque<>();
        List<BlockPos> found = new ArrayList<>();
        queue.add(start);
        while (!queue.isEmpty() && found.size() < max) {
            BlockPos c = queue.poll();
            if (!seen.add(c)) continue;
            if (!level.hasChunkAt(c) || !isGlass(level.getBlockState(c))) continue;
            found.add(c);
            for (net.minecraft.core.Direction d : net.minecraft.core.Direction.values()) queue.add(c.relative(d));
        }
        for (BlockPos p : found) level.destroyBlock(p, false);
    }
}
